<?php

namespace App\Http\Controllers\Admin;

class ReportController extends BaseAdminController
{
    // Placeholder - akan diimplementasikan nanti
}
