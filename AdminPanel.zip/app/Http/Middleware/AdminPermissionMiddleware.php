<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminPermissionMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        if (!auth('admin')->check()) {
            return redirect()->route('admin.login');
        }

        /** @var \App\Models\Admin|null $admin */
        $admin = auth('admin')->user();

        if (!$admin) {
            return redirect()->route('admin.login');
        }

        if (!$admin->hasPermission($permission)) {
            return response()->view('admin.errors.permission-denied', [], 403);
        }

        return $next($request);
    }
}
