<?php

namespace App\Http\Controllers\Admin;

class ReviewController extends BaseAdminController
{
    // Placeholder - akan diimplementasikan nanti
}
